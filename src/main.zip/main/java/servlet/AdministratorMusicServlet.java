package servlet;
/*
* 管理员对音乐操作
*
* */
import bean.Music;
import com.alibaba.fastjson.JSON;
import dao.MusicDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = "/AdministratorMusicServlet")
public class AdministratorMusicServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String method = request.getParameter("method");
        if("findUserListByKeyWord".equals(method)){
            String keyWord = request.getParameter("keyWord");
            System.out.println(keyWord);
            MusicDao dao = new MusicDao();
            List<Music> list = dao.secarhMusicByKeyWord(keyWord);
            // 将List对象转换为json数组
            System.out.println(JSON.toJSONString(list));
            response.getWriter().println(JSON.toJSONString(list));
        }else if("delete".equals(method)){
            Integer musicId = Integer.parseInt(request.getParameter("musicId"));
            MusicDao dao = new MusicDao();
            dao.deleteMusic(musicId);
            response.getWriter().println(JSON.toJSONString("hello"));
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
